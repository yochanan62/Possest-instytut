# Manifest Structure

This is the structural bifurcation point.

- `swamp/` holds pre-formal, raw material intensities.
- `glossary/` defines PQF-specific operators.
- `topologies/` explores alignments and misalignments of access.
