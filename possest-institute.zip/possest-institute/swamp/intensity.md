# Swamp

The swamp is the pre-formal condition of intensity — a thickness that resists topology.

This filter traces proto-structures that never crystallize into form.
